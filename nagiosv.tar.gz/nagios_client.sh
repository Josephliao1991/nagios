cd nagios/
useradd nagios
tar xzf nagios-plugins-2.1.1.tar.gz
cd nagios-plugins-2.1.1
yum install gcc* -y
yum install xinetd openssl* -y
./configure
make && make install
cd ..
tar zxvf nrpe-2.15.tar.gz
cd nrpe-2.15
./configure
make all && make install-plugin && make install-daemon && make install-daemon-config && make install-xinetd
cd ..
cp -r nrpe /etc/xinetd.d/nrpe 
cp -r nrpe.cfg /usr/local/nagios/etc/nrpe.cfg
service xinetd restart
